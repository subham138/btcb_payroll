<script>
	
	 $(".sch_cd").select2();   // Code For Select Write Option
</script>

        </section>

        <footer class="sticky-footer" style="background-color: #a0a7ac; text-align: center;">

           <span style="line-height: 5; font-size: 12px;"><strong>Copyright © Synergic Softek Solutions PVT. LTD. 2020</strong></span>

        </footer>

    </body>

    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>

</html>