<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<link rel="icon" href="favicon.ico">
 
 <!--<meta name="viewport" content="width=device-width, initial-scale=1.0"> -->
<link href="<?php echo base_url("/assets/css/bootstrap.min.css");?>" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="<?php echo base_url("/assets/css/style1.css");?>">
 <title>The West Bengal State Co-operative Marketing Federation Ltd.</title>
</head>
<style>
div.block {
	margin: 20px;
   height: 195px;
   border: 10px;
   text-align: center;
   padding: 55px;
	flex: 1;
	border-radius: 25px;
	color: white;
}

div.block:active{
	transform: translateY(4px);
}

a{
	font-size: 25px;
}
a:hover{
	text-decoration: none;
}
.block:hover{
	-webkit-box-shadow: 5px 5px 30px 20px #CCCCCC;
	box-shadow: 5px 5px 30px 20px #CCCCCC;
}
</style>
<body>
	<div class="">
    	<div class="header">
    		<div class="row">
        <div class="col-md-4"></div>
        <div class="col-md-4">
        	<center><img src="<?=base_url()?>benfed.png"/></center>

        	 </div>
    	 </div>
    	</div>
		 
		<div class="row">
		
		 <div class="col-md-4">
			<!-- <a class="text-white hover" href="<?=base_url()?>index.php/User_Login/login">
				<div class="block index_btn1">
					Paddy<br>Procurement
				</div>    
			</a> -->
		 </div>  
		
	    <div class="col-md-4">
			<a class="text-white" href="<?=base_url()?>index.php/Fertilizer_Login/login">
				<div class="block index_btn3">
					Payroll
				</div>
			</a>  
		 </div>
		</div>

		<!-- 		<div class="row">
				 <div class="col-md-4">
					<a class="text-white" href="#">
						<div class="block index_btn4">
						Demo
						</div>
					</a> 
				 </div>  
				 <div class="col-md-4">
					<a class="text-white" href="#">
						<div class="block index_btn5">
						Softek
						</div>
					</a>
				 </div>
			   
				 <div class="col-md-4">
					<a class="text-white" href="http://www.synergicportal.in/mkt">
						<div class="block index_btn7">
						 Marketing
						</div>
					</a>  
				 </div>
				</div>  -->    
	</div>
</body>
</html>
